###########################################EJERCICIO 1#################################################

##################
##OPCI�N A,B,C ### TODOS SE HACEN IGUAL: COMPA�IA A�REA, ELECTRODOM�STICOS, IMPERFECCIONES
##################

x=c(0,1,2,3,4,5,6,7,8,9,10)
f=c(0.26 , 0.17 , 0.12 , 0.09 , 0.08 , 0.06 , 0.05 , 0.05 , 0.04 , 0.04 , 0.04)
names(f) <- x

#1# Media
miu.x=sum(x*f)


#2# Mediana
cumsum(f) #despues de hacer cumsum elergir los dos numero que estan al rededor del 0,5 y coger el mayor.
x[#valorelegido] ; #En este caso, mediana -> x = 2

  
#3# Varianza
var.x=sum(((x-miu.x)^2)*f)


#4# Experimento selecci�n aleatoria de 10m de tejido donde se cuenta n� imperfecciones. 
    #Cual es la instrucci�n correcta para simular una muestra de 1000 observaciones?

    #Opci�n posible 1 (en azul: x y fx)
    sample(x,1000,replace = T,f)

    #Opci�n posible 2 (en azul: n y fx)
    trials = sample(seq(0,n),1000,replace = T,prob = f)
    
 
#5# Elegir gr�fica correcta
    
!!!!!!!!!!AQUI HAY DUDA!!!!!!!!!! 
      
    Si en #4# has elegido 1 --> DUDA!!!! Gr�fica de lineas verticales ascendiente o [random]
    SI en #4# has elegido 2 --> DUDA!!!! [Gr�fica de lineas verticales descendiente] o gusano descendiente


    
    


    
    
    
    
    


###########################################EJERCICIO 2#################################################

##################
### OPCI�N A ##### TODOS SE HACEN IGUAL: NEUMATICO CAMI�N, ING QUIMICA
################## prob=[44]% de los camiones/de los fallos ; De los siguientes size=[39] camiones/fallos...

#1# Prob. de que [11] fallos/camiones sean causados por el operador ?
dbinom(11, size=39, prob=0.44)
    
    
#2# Prob. de que [15] o m�s fallos/camiones tengan explosion/causados x operador ?
!!CUIDADO PONER BIEN TODO, COMPROBAR A CALCULADORA EL BINOMIAL!!
      
pbinom(15-1,size=25,prob=0.52,lower.tail = FALSE)

    
#3# Si un exp. cuenta fallos en los siguientes n=[39] fallos, simular [500.000] exp, prom. de fallos ?
n*p
39*0.44
   
 
#4# Grafica correcta?
!!!!!!CUIDADO AL ELEGIR!!!!!!!
  
x2 = seq(0,39,1)
fx2 = dbinom(x2,n,p)
plot(x2,fx2,pch=13,type="p")
for(i in 1:39)
{lines(c(x2[i], x2[i]), c(0, fx2[i]),col="red")}




##################
### OPCI�N B ##### TODOS SE HACEN IGUAL: ALAMBRE FINO, CONEJOS
################## landa=[30]promedio

lamda<- 30

#1a# Probabilidad !NO! se encuentren m�s de [28]imperfecciones (entre 0 y 28) ?
#1b# Probabilidad [19] conejos !O MENOS! se encuentren en un acre ?
1-ppois(31,lamda)


#2a# Probabilidad al menos [79] imperfecciones en [3] cm alambre ?
#2b# Probabilidad exactamente [31] conejos en [2] acres ?
lamda2<-3*lamda
dpois(30,lamda2)   


#3a# Inspeccion 1cm alambre. Simulan [300.000] exp. Varianza de imperfecciones en 1mm es?
#3b# N� conejos encontrados en un acre. Simulan [500.000] exp. Varianza conejos en 1 acre?
simu_2.1<-rpois(300000,lambda)
var(simu_2.1)


#4# Grafico correcto?
!!!!!!CUIDADO AL ELEGIR!!!!!!!
  
La grafica es el gusano. El valor de Landa ser� el punto medio de la curva, pues el valor del eje X




















###########################################EJERCICIO 3#################################################

##################
### OPCI�N A ##### TODOS SE HACEN IGUAL: PIEZA ELECTRONICA, PERSONAS LLAMADA
################## el tiempo de falla es una VAC X con funcion densidad: [3*raiz(2)....] y 0<x<8

#1a# Grafico correcto funcion densidad? (el que tiene raiz)
!!!MUCHO CUIDADO ELEGIR MUY BIEN!!!
  
f.3 <- function(x) {(3*sqrt(2)*sqrt(x))/(64)}
x.3 <- seq(0,8,0.001)
F1 <- (3*sqrt(2)*sqrt(x.3))/(64)
curve(f.3,0,8,col="red",lwd="2",main="Funci� de densitat",xlab="x",ylab="f(x)")


#1b# Grafico correcto funcion densidad? (el que tiene suma), va de 8<x<10
x = seq(8,10, by= 0.001)
fx = (x/45)+(3/10)

!!!AJUSTAR LIM PARA VERLO MEJOR!!!
  
plot(x,fx,type = "l",xlim=c(7,10),ylim = c(0.45,0.6))


#2# Si su codigo es ...., cual instrucci�n con muestra [4000]?
trials<-sample(x.3,4000,replace=T,prob=F1)


#3# Promedio con muestra simulada [400.000] observaciones. X?
mean(trials)

#4# Varianza """""""""""""" ?
var(trials)















###########################################EJERCICIO 4#################################################

##################
### OPCI�N A ##### TODOS SE HACEN IGUAL: EXAMEN, PROBETA.
################## Un examen distrib. N, media=[76],var=[349.7] /Laborat. media=[4.6], desv=[0.79]
miu=76
sigma=sqrt(349.7) #CUIDADO ESTO ES VAR

media.labo=6
desv=1.08 #CUIDADO ESTO ES DESV

#1# Grafico correcto?

!!! CUIDADO ELEGIR BIEN !!!
  
curve(dnorm(x =x, miu, sigma),xlim=c(0,150),ylim=c(0,0.022))
curve(dnorm(x =x, media.labo, desv),xlim=c(0,10),ylim=c(0,0.55))


#2# Prob. persona calificacion superior a [54.6]? / Probeta superior a [1.3]cl ?
pnorm(c(54.6),76,sqrt(349.7),lower.tail=F) #LOWER TAIL FALSE SERIA QUE COGE LO DE ENCIMA #LABO!
pnorm(c(1.7),6,1.08,lower.tail=F) #LOWER TAIL FALSE SERIA QUE COGE LO DE ENCIMA #EXAMEN!



#3# Prob. califacion entre [55.6] y [99]? / Probeta entre 3 y 5.6
A=pnorm(c(55.6), mean=76, sd=sqrt(349.7), lower.tail=TRUE);A
B=pnorm(c(99), mean=76, sd=sqrt(349.7), lower.tail=TRUE);B
resultado=B-A;resultado #Calificacion

A=pnorm(c(3.8), mean=6.2, sd=1.21, lower.tail=TRUE);A
B=pnorm(c(7.2), mean=6.2, sd=1.21, lower.tail=TRUE);B
resultado=B-A;resultado #Probeta


#4# NO-Aptos el [19]% de las notas mas bajas. Valor frontera entre Aptos-Noaptos? / Labo: Percentil [0.81] f(dens)
qnorm(c(0.19), mean=76, sd=sqrt(349.7))#notas = 59.5831!
qnorm(c(0.5), mean=6.2, sd=1.21, lower.tail=TRUE)#labo

#parte 4EL PORCENTAGE NO SUPERA UNA ROBABILIDAD
prob_NO_superada=0.5
qnorm(prob_NO_superada, mean=6.2, sd=1.21, lower.tail=TRUE)

#PARTE 5
#Distribucion normal
mudm<-6*12 #Valor de mu en la distribucion
vardm<- 1.21*sqrt(11)# Varianza de distribucion
valor1<-76.2
pnorm(c(valor1), mean=mudm, sd=vardm, lower.tail=TRUE)


  !!! ESTE OK !!!
pnorm(c(54.4), mean=4.6*11, sd=0.79*sqrt(11), lower.tail=T)
#mean = media * n� probeta ; sd = sd *raiz(probeta)

miu=80
sigma=sqrt(382.2)
curve(dnorm(x =x, miu, sigma),xlim=c(0,150),ylim=c(0,0.02))
pnorm(c(109.9),miu,sigma,lower.tail=F)
1-pnorm(84,miu,sigma,lower.tail=F)-pnorm(47.9,miu,sigma,lower.tail=T)
qnorm(c(0.23), miu, sigma, lower.tail=T)
pnorm(c(58.7), mean=miu*12, sd=sigma*sqrt(12), lower.tail=TRUE)
pnorm(c(65.55559), 80*5, sd=382.2*sqrt(5), lower.tail=TRUE)




################################################################







