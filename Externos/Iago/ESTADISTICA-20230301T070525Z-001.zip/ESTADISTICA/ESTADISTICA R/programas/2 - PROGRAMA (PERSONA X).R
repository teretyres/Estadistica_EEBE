##1
x <- 0:12
x

fx <- c(0.143,0.133,0.123,0.113,0.103,0.073,0.073,0.063,0.063,0.053,0.024,0.023,0.013)
fx
names(fx)=x
mu <- sum(x*fx)
mu

Fx <- cumsum(fx);Fx
(Fx['2']+Fx['3'])/2

sigma2 <- sum(((x-mu)^2)*fx)
sigma2

#4
n=12
fx
trials = sample(seq(0,n),1000,replace=T, prob=fx)
mean(trials)
sd(trials)^2
plot(x,fx,pch=16)
lines(x,fx,col='red')

##2
lamda<- 13
#1)P(X<=19)= 
ppois(19,lamda)
#2)P(X=16)=0.01920602
lamda2<-2*lamda; lamda2
dpois(31,lamda2)   
#3) 21
media<-lamda; media
varianza <- 
#4) (GR?FICA)
x2 <- seq(0,60,0.0001)
fx2<- dpois(x2,lamda)
plot(x2,fx2,pch=16,type='p')
for (i in 0:60)
  {lines(c(x2[i], x2[i]), c(0, fx2[i]))}
lines(x2,fx2

##3
x <- seq(0,10,by=0.001)
x
fx <- (3*sqrt(10)/200)*sqrt(x)
fx
trials <- sample(x,100000,replace = T,prob=fx)
mean(trials)
sd(trials)^2
plot(x,fx)

##4
#a
.x <- seq(0.5, 17, length.out=1000) 
plot(.x, dnorm(.x, mean=6.2, sd=1.42), cdf=FALSE, xlab="x", ylab="Density",main=paste("Normal Distribution:  Mean=6.2, Standard deviation=1.42"))
#b
pnorm(c(1.4), mean=6.2, sd=1.42, lower.tail=FALSE)
#c
A=pnorm(c(5.4), mean=6.2, sd=1.42, lower.tail=TRUE);A
B=pnorm(c(7.2), mean=6.2, sd=1.42, lower.tail=TRUE);B
resultado=B-A;resultado
#d
qnorm(c(0.9), mean=6.2, sd=1.42)#forma 1
qnorm(c(0.9), mean=6.2, sd=1.42, lower.tail=TRUE)#forma 2
#e
pnorm(c(74.4), mean=6.2*13, sd=1.42*sqrt(13), lower.tail=TRUE)
#num cl; mean = media * num prob ; sd = sd *raiz(prob)