#PROBLEMA 4: T-TEST (varianza poblaci�n desconocida)

n <- 96; 
media <- 172;
desviacion <- 6;
confianza <- 0.99;

t<-qt(confianza+(1-confianza)/2,n-1);
L<-t*desviacion/sqrt(n);

#Resultado
intervalo=media+c(-L,L);intervalo
