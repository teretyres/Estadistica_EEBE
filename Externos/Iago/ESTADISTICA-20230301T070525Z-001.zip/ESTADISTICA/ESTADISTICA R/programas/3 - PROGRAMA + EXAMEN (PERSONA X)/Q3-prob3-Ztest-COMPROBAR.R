#Problema 3:  Z-TEST (varianza de la poblacion conocida)


#1
nivel_Confianza1 <- 000;
varianza <-000;

z.test(datos,sd=desviacion,conf.level=nivel_confianza)



#2
error <-000;
nivel_Confianza2 <- 000;

z<-qnorm(c(nivel_confianza2+(1-nivel_confianza2)/2),mean=0,sd=1,lower.tail=TRUE)