#Problema 3: T-TEST (Varianza de la Poblacion Desconocida)

datos <-c(5.73,5.41,5.25,4.98,4.61,5.38,5.88,5.57,5.27,5.2,5.33,5.35);
nivel_confianza <- 0.99;


t.test(datos,conf.level=nivel_confianza)

#Coger los dos valores de bajo de XX percent confidence interval:





