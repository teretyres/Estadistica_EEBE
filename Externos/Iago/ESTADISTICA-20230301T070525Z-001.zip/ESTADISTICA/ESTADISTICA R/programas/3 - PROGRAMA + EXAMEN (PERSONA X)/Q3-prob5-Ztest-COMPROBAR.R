#Problema 5: Z-TEST (varianza de la poblacion Conocida)

maquina1<-c(3.56,3.40,3.48,3.50,3.42,3.43,3.52,3.49,3.44,3.50,3.48,3.56,3.50,3.52,3.47,3.48,3.46,3.50,3.56,3.38);
maquina2<-c(3.41,3.37,3.47,3.49,3.45,3.44,3.50,3.49,3.46,3.46,3.55,3.52,3.44,3.50,3.45,3.44,3.48,3.46,3.52,3.46);
especimen <- c(19.8,18.5,17.6,16.7,15.8,15.4,14.1,13.6,11.9,11.4,11.4,8.8,7.5,15.4,15.4,19.5,14.9,12.7,11.9,11.4,10.1,7.9)

datos <- maquina;#Hay que escoger entre: maquina1  maquina2   especimen  
nivel_significacion <- 0.05;
mu0 <- 3.5;
alternativa <- "two.sided";#Hay que escoger entre: "two.sided"  "less"   "greater"  (copiar y pegar con las comillas)
varianza <- 0.002;



z.test(datos,mu=mu0,sd=sqrt(varianza),alternative=alternativa,conf.level=1-nivel_significacion)


#A mu <>=/0
#B mu0
#C z O t
#D estad. observado = z
#E pvalue = ....
#F SI HAY....