#ANTES DE EMPEZAR


#Copia y pega en la consola

      install.packages("TeachingDemos")
      
#Dale al enter

      
      

#Copia y pega en la consola
      
      library("TeachingDemos")
      
#Dale al enter


      
      
      
      
#Y ahora a rellenar los 000