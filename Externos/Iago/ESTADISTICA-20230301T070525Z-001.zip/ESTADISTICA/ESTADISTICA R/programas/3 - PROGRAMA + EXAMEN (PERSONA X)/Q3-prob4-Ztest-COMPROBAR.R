#PROBLEMA 4: Z-TEST (varianza de la poblacion conocida)


n <- 000; 
media <- 000;
desviacion <- 000;#de la muestra
confianza <- 000;
varianza <- 000;#de la poblacion

z<-qnorm(c(confianza+(1-confianza)/2),mean=0,sd=1,lower.tail=TRUE); 		
L<-z*sqrt(varianza)/sqrt(n);
intervalo=media+c(-L,L);intervalo