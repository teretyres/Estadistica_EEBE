# PROBLEMA 1


media <- 3.9;
desviacion_tipica <- 0.65;
nb <- 8;
nc <- 78;
valor <- 3.705;


a <- pnorm(c(valor),mean=media,sd=desviacion_tipica,lower.tail=FALSE); a
b <- pnorm(c(valor),mean=media,sd=desviacion_tipica/sqrt(nb),lower.tail=FALSE); b
c <- pnorm(c(valor),mean=media,sd=desviacion_tipica/sqrt(nc),lower.tail=FALSE); c


