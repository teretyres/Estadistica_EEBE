#PROBLEMA 2


promedio <- 3.09;
varianza <- 5.242;



n1 <- 12;
n2 <- 12*5;

desviacion1<-sqrt(varianza)/sqrt(n1);desviacion1
frase1 <- "Teoricamente NO, sin embargo SI"

desviacion2<-sqrt(varianza)/sqrt(n2);desviacion2
frase2 <- "Teoricamente similares, y resultados confirman"

#1
promedio

#2
desviacion1

#3
frase1

#4
promedio

#5
desviacion2

#6
frase2


