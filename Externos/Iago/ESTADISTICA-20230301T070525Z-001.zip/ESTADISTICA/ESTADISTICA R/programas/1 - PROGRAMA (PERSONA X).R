x=seq(100,375,25);x
fx=c(0.081,0.151,0.031,0.151,0.071,0.041,0.081,0.101,0.081,0.071,0.009);fx
names(fx)=x;fx

mu=sum(x*fx);mu

F=cumsum(fx);F

sigma2=sum(((x-mu)^2)*fx);sigma2



#2

lamda=30
P[X<=28]=0.01
ppois(28,lamda)

lamda2=3*lamda;lambda2
dpois(79,lamda2)

#4) (GR?FICA)
x2 <- seq(0,60,1)
fx2<- dpois(x2,lamda)
plot(x2,fx2,pch=16,type='p')
for (i in 0:60)
 lines(c(x2[i], x2[i]), c(0, fx2[i]))


3
#1
x = seq(7,10, by= 0.001)
fx = (x/255)+(3/10)
plot(x,fx,type = "l",xlim=c(6,10),ylim = c(0,0.7))

f<-function(x)
{
  out <- (1/45)*x+(3/10)

  out[x<=8] <- 0
  out[x>=10] <- 0
  out
}
x <- seq(8,10,0.001)
plot(x, f(x), type="l", col="blue")

x = seq(8,10,by=0.001);fx=(1/45)*x+(3/10)
trials = sample(x,size=200000,replace=T, prob=fx)
trials
mean (trials)#media
var(trials)#varianza


4.

mu=4.6
sigma=0.79
#1
x = seq(mu-4*sigma, mu+4*sigma, length(1000))
f = dnorm(x,mean = mu, sd = 18.76966)
sd=sqrt(sigma);sd

#2
pnorm(c(1.5), mean=4.6, sd=0.79, lower.tail=FALSE)

#3
1-pnorm(5.6,mu,sigma,lower.tail=FALSE)-pnorm(3,mu,sigma,lower.tail=TRUE)

#4
qnorm(c(0.81), mean=4.6, sd=0.79, lower.tail=TRUE)

#5
pnorm(c(54.4), mean=4.6*11, sd=0.79*sqrt(11), lower.tail=TRUE)