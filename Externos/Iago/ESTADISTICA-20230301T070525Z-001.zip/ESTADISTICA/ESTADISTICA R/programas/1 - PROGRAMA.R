#EJERCICIO 1

n<-24
x1<-c(0:n)*(pi/n)
sum(x1)
y <- x1[-c(24,17,10)]
sum(sin(x1))-sum(cos(y))

Falso







# EJERCICIO 2
read.table("Datos_Sesion3/coches.txt",header=TRUE, sep="\t",dec=".")

CUIDADO MIRAR SI EL DECIMAL ES PUNTO O COMA, SI HAY HEADER O NO, LA SEP...






#EJERCICIO 3 (RECORDAR LO QUE NOS PIDEN, SHAPE, AREA...)

##Sacamos ni
mis_datos=rock
breaks = seq(from=0,to=0.5, by=0.1)
corte=cut(mis_datos$shape,breaks,right= FALSE)
ni <- table(corte)

##Sacamos Ni
Ni <- cumsum(ni)

##Sacamos fi
fi <- prop.table(ni)

##Sacamos Fi
Fi <- cumsum(fi)

##Juntamos todo para visualizar
TablaFrec <- cbind(ni,fi,Ni,Fi)
TablaFrec










#EJERCICIO 4

TIPOS DE GRAFICOS, CONSULTAR TEORIA O EXAMENES RESUELTOS









#EJERCICIO 5
rm(list=ls())
data=rock;


##Si nos piden diagrama de puntos...
dotchart(data$perm)

#Si nos piden tallos hojas...
stem(data$perm)

#Si nos piden otra cosa, consultar guias








#EJERCICIO 6
## Cuidado revisar lo que nos piden!!!!!!!!!!!!!!!

mis_datos=mtcars
mean(mis_datos$qsec)
median(mis_datos$drat)
quantile(mis_datos$mpg,seq(0.25,0.75,by=0.25))
quantile(mis_datos$mpg,0.18)
quantile(mis_datos$mpg,seq(0.18,0.82,by=0.1))
IQR(mis_datos$qsec)
sd(mis_datos$cyl)
var(mis_datos$drat)












#EJERCICIO 7  #los que te salga primero es Y  lo segundo es X

mis_datos=mtcars

x <- mis_datos$mpg#drat
y <- mis_datos$qsec#disp
xbar <- mean(x)
ybar <- mean(y)

m <- sum((x - xbar)*(y - ybar)) / sum((x - xbar)^2)
b <- ybar - m*xbar

mod <- lm(qsec~mpg,data=mis_datos)#disp drat
summary(mod)










  
#EJERCICIO 8

X <- c(1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10)
Y <- c(23.3,31.3,32.5,41.2,50.8,48.1,47.8,42,47,58.5,49.9,66.1,62.3,64.8,67.7,72.5,78.5,85.3,99,79.7)
mod <- lm(Y~X)
plot(X,Y)
abline(mod)

predict(mod,data.frame(X=15))









#EJERCICIO 9

x<-c(1,2,4,5,8,10,11,14,16,20);x
y<-c(518,929,2128,3867,17888,39238,75286,264017,723193,5609252);y

model2=lm(log(y)~x)
summary(model2)
plot(x,y)

pred <- predict(model2,data.frame(x=26))
exp(pred)
