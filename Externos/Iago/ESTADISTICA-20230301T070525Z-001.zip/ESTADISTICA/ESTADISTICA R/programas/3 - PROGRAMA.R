


#Antes de empezar escribimos estas dos lineas de codigo en el R para instalar un nuevo paquete estadistico

install.packages("TeachingDemos")
library("TeachingDemos")



%PROBLEMA 1


media <- 8
desviacion <- 1.4;
n1 <- 9; #Numero muestras apartado b
n2 <- 86; #Numero muestras apartado c
valor <- 7.78;

#Si me dice en el enunciado que es aproximadamente NORMAL

a <- pnorm(c(valor),mean=media,sd=desviacion,lower.tail=FALSE); a
b <- pnorm(c(valor),mean=media,sd=desviacion/sqrt(n1),lower.tail=FALSE); b
c <- pnorm(c(valor),mean=media,sd=desviacion/sqrt(n2),lower.tail=FALSE); c


#Si no me dice nada de normal en el enunciado

a <- pnorm(c(valor),mean=media,sd=desviacion,lower.tail=FALSE); a
#No podemos hacer el b y ponemos XX
c <- pnorm(c(valor),mean=media,sd=desviacion/sqrt(n2),lower.tail=FALSE); c



%PROBLEMA 2


promedio <- 3.15
varianza <- 6.668;

#apartados 1 y 2 y 3: me dicen 1 año (12 meses) y 600 clientes

n1 <- 12;
n2 <- 400;
a<-promedio; a
b<-sqrt(varianza)/sqrt(n1);b



#teoricamente no tienen que ser similares, sin embargo en este caso si lo son



#siguientes apartados 1 y 2 y 3: ahora me dicen 5 años (60 meses) y 600 clientes	

n1 <- 60;
n2 <- 400;
a<-promedio; a
b<-sqrt(varianza)/sqrt(n1);b


#teoricamente deberian ser similares y los resultados lo confirman




%PROBLEMA 3


datos <- c(405.3,486.2,454.5,480.8,395.6,431.8,431.8,478.7,421.6,403.7,495.4,439.1)
nivel_confianza <- 0.98


#Si no me dan la varianza poblacional
t.test(datos,conf.level=nivel_confianza)

#Si me dan la varianza poblacional

standard_deviation <- 4.4;
z.test(datos,sd=standard_deviation,conf.level=nivel_confianza)

#Si me piden la n para tener un margen de error con una confianfa

margen_error <- 0.6098;
confianza <- 0.95;
varianza=standard_deviation^2;
z <-qnorm(c(confianza+(1-confianza)/2),mean=0,sd=1,lower.tail=TRUE); 
n=(z^2*varianza)/(margen_error^2); n


%PROBLEMA 4

n <- 90; 
media <- 22.5;
desviacion <- 1.2;
confianza <- 0.99;

#Si no me dan la varianza poblacional

t<-qt(confianza+(1-confianza)/2,n-1);
L<-t*desviacion/sqrt(n);
intervalo=media+c(-L,L);intervalo


#Si me dan la varianza poblacional

varianza <- 3.37;

z<-qnorm(c(confianza+(1-confianza)/2),mean=0,sd=1,lower.tail=TRUE); 		
L<-z*sqrt(varianza)/sqrt(n);
intervalo=media+c(-L,L);intervalo

#Si me piden la n para tener un margen de error con una confianfa

margen_error <- 0.2;
confianza <- 0.95;
z<-qnorm(c(confianza+(1-confianza)/2),mean=0,sd=1,lower.tail=TRUE); 
n=(z^2*varianza)/(margen_error^2); n



%PROBLEMA 5

maq1<-c(3.56, 3.40, 3.48, 3.50, 3.42, 3.43, 3.52, 3.49, 3.44, 3.50, 3.48, 3.56, 3.50, 3.52, 3.47, 3.48, 3.46, 3.50, 3.56, 3.38);
maq2<-c(3.41, 3.37, 3.47, 3.49, 3.45, 3.44, 3.50, 3.49, 3.46, 3.46, 3.55, 3.52, 3.44, 3.50, 3.45, 3.44, 3.48, 3.46, 3.52, 3.46);

nivel_significacion <- 0.05;

#Si no me dan la varianza poblacional tenemos que utilizar la t-student

#Si me piden hacer un test de la maquina 1 y me piden si es menor a 3.5:
alternativa<-"greater";alternativa
mu0=3.5;mu0
t.test(maq1,mu=mu0,alternative=alternativa,conf.level=1-nivel_significacion)

#Si me piden hacer un test de la maquina 2 y me piden si es menor a 3.5:
alternativa<-"greater";alternativa
mu0=3.5;mu0
t.test(maq2,mu=mu0,alternative=alternativa,conf.level=1-nivel_significacion)

#Si me piden hacer un test de la maquina 1 y me piden si es mayor a 3.5:
alternativa<-"less";alternativa
mu0=3.5;mu0
t.test(maq1,mu=mu0,alternative=alternativa,conf.level=1-nivel_significacion)

#Si me piden hacer un test de la maquina 2 y me piden si es mayor a 3.5:
alternativa<-"less";alternativa
mu0=3.5;mu0
t.test(maq2,mu=mu0,alternative=alternativa,conf.level=1-nivel_significacion)

#Si me piden hacer un test de la maquina 1 y me piden si es igual a 3.5:
alternativa<-"two.sided";alternativa
mu0=3.5;mu0
t.test(maq1,mu=mu0,alternative=alternativa,conf.level=1-nivel_significacion)

#Si me piden hacer un test de la maquina 2 y me piden si es igual a 3.5:
alternativa<-"two.sided";alternativa
mu0=3.5;mu0
t.test(maq2,mu=mu0,alternative=alternativa,conf.level=1-nivel_significacion)


#Si me dan la varianza poblacional tenemos que utilizar la normal

varianza <- 0.002;

#Si me piden hacer un test de la maquina 1 y me piden si es menor a 3.5:
alternativa<-"greater";alternativa
mu0=3.5;mu0
z.test(maq1,mu=mu0,sd=sqrt(varianza),alternative=alternativa,conf.level=1-nivel_significacion)

#Si me piden hacer un test de la maquina 2 y me piden si es menor a 3.5:
alternativa<-"greater";alternativa
mu0=3.5;mu0
z.test(maq2,mu=mu0,sd=sqrt(varianza),alternative=alternativa,conf.level=1-nivel_significacion)

#Si me piden hacer un test de la maquina 1 y me piden si es mayor a 3.5:
alternativa<-"less";alternativa
mu0=3.5;mu0
z.test(maq1,mu=mu0,sd=sqrt(varianza),alternative=alternativa,conf.level=1-nivel_significacion)

#Si me piden hacer un test de la maquina 2 y me piden si es mayor a 3.5:
alternativa<-"less";alternativa
mu0=3.5;mu0
z.test(maq2,mu=mu0,sd=sqrt(varianza),alternative=alternativa,conf.level=1-nivel_significacion)

#Si me piden hacer un test de la maquina 1 y me piden si es igual a 3.5:
alternativa<-"two.sided";alternativa
mu0=3.5;mu0
z.test(maq1,mu=mu0,sd=sqrt(varianza),alternative=alternativa,conf.level=1-nivel_significacion)

#Si me piden hacer un test de la maquina 2 y me piden si es igual a 3.5:
alternativa<-"two.sided";alternativa
mu0=3.5;mu0
z.test(maq2,mu=mu0,sd=sqrt(varianza),alternative=alternativa,conf.level=1-nivel_significacion)



#PROBLEMA 6


datos <- c(19.8, 18.5, 17.6, 16.7, 15.8, 15.4, 14.1, 13.6, 11.9, 11.4, 11.4, 8.8, 7.5, 15.4, 15.4, 19.5, 14.9, 12.7, 11.9, 11.4, 10.1, 7.9)
nivel_significacion <- 0.10;

#Si no me dan la varianza poblacional tenemos que utilizar la t-student

#Si me piden hacer un test para comprobar si la media es menor a 10:
alternativa<-"greater";alternativa
mu0=10;mu0
t.test(datos,mu=mu0,alternative=alternativa,conf.level=1-nivel_significacion)

#Si me piden hacer un test para comprobar si la media es mayor a 10:
alternativa<-"less";alternativa
mu0=10;mu0
t.test(datos,mu=mu0,alternative=alternativa,conf.level=1-nivel_significacion)

#Si me piden hacer un test para comprobar si la media es igual a 10:
alternativa<-"two.sided";alternativa
mu0=10;mu0
t.test(datos,mu=mu0,alternative=alternativa,conf.level=1-nivel_significacion)




#Si me dan la varianza poblacional tenemos que utilizar la normal

varianza <- 12.25;

#Si me piden hacer un test para comprobar si la media es menor a 10:
alternativa<-"greater";alternativa
mu0=10;mu0
z.test(datos,mu=mu0,sd=sqrt(varianza),alternative=alternativa,conf.level=1-nivel_significacion)

#Si me piden hacer un test para comprobar si la media es mayor a 10:
alternativa<-"less";alternativa
mu0=10;mu0
z.test(datos,mu=mu0,sd=sqrt(varianza),alternative=alternativa,conf.level=1-nivel_significacion)

#Si me piden hacer un test para comprobar si la media es igual a 10:
alternativa<-"two.sided";alternativa
mu0=10;mu0
z.test(datos,mu=mu0,sd=sqrt(varianza),alternative=alternativa,conf.level=1-nivel_significacion)

