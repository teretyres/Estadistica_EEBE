#problema 1#

x=c(0,1,2,3,4,5,6,7,8,9,10,11,12)
x
fx=c(0.174,0.153,0.113,0.093,0.093,0.083,0.073,0.073,0.063,0.033,0.023,0.013,0.013)
fx

#a
mu = sum(x*fx)
mu

#b
cumsum(fx)

#c
var = sum(((x-mu)^2)*fx)
var

#d
n = 12
trials = sample(seq(0,n),1000,replace=TRUE, prob=fx)
trials
plot(fx,type="p",pch=16)
for(i in 1:12)
  lines(c(xi[i], xi[i]), c(0, f[i]))

#problema 2

#a
#size =35, prob = 0.44
dbinom(3, size=25, prob=0.42)
1-pbinom(23,size=29,prob=0.48,lower.tail = TRUE)
1-0.6479183

1-pbinom(23,29,0.48)

n= 35
p = 0.44
n*p
35*0.44

x2 = seq(0,35,1)
x2
fx2 = dbinom(x2,n,p)
plot(x2,fx2,pch=16,type="p")

  
#3Problema 
#a
fx = ((3*sqrt(38))/361)*sqrt(x)
x = 2
fx

#b
x = seq(2,7,by=0.001);fx=1/45*x+1/10
trials = sample(x,size=400000,replace=T, prob=fx)
trials
mean (trials)
var(trials)

#problema 4#

#a
.x <- seq(1.1, 15.1, length.out=1000) 
plot(.x, dnorm(.x, mean=7.2, sd=1.49), cdf=FALSE, xlab="x", ylab="Density",main=paste("Normal Distribution:  Mean=7.2, Standard deviation=1.49"))

#b
pnorm(c(1.5), mean=7.2, sd=1.49, lower.tail=FALSE)

#c
P1 = pnorm(c(5.2), mean=7.2, sd=1.49, lower.tail=TRUE)
P1
P2 = pnorm(c(7.2), mean=7.2, sd=1.49, lower.tail=TRUE)
P2
P2-P1 #SOL 

#d
qnorm(c(0.37), mean=7.2, sd=1.49, lower.tail=TRUE)

#e
12*7.2
12*1.49
pnorm(c(94.1), mean=86.4, sd=17.88 , lower.tail=TRUE)
