##problema 1##

xi = c(46,47,48,49,50,51,52,53,54) #capacidades
f = c(0.095,0.165,0.075,0.065,0.075,0.165,0.115,0.125,0.12) #probabilidades
#1#
mu = sum(xi*f); mu #1 media.
#2#la mediana la calculas sumant probabilitats fins que pasis el 0,5.
F = cumsum(f);
F
#3#
var=sum(((xi-mu)^2)*f);
var
#4
trials = sample(xi,1000,prob=f,replace =TRUE)
trials
# la x seria la xi anterior, n=muestras a simular mi caso 1000, 
# replace=T para poder repetir valores, fx seria lo mismo que prob=fx -> probabilidad de que salga cada xi.
#5#

plot(f,type="p",pch=16)
for(i in 1:12)
lines(c(xi[i], xi[i]), c(0, f[i]))

##problema 2##

#1#
.Table <- data.frame(Probability=dpois(5:32, lambda=10));
rownames(.Table) <- 5:32 
print(.Table)
#miras en  la lista las veces que te den, en mi caso 21.#

#2#
ppois(c(15), lambda=10, lower.tail=FALSE) #2 c(VUESTRO NUMERO) lambda(VUESTRA LAMBDA)
#tail=FALSE porque dice mas de x veces, tail=TRUE si dice menos de x veces.

#3#
#La varianza es el valor de lambda lo dice el formulario POISSON.

#4#
hist(.Table)

##pregunta 3##

#1#
fx = (3/58)*(10-x^2) #1 funcion densidad sustituir los limites y mirar valores.
fx;

#2#
x = seq(-1/1,by=0.001); fx=(3/58)*(10-x^2) #2 Mi codigo es este.
trial = sample(x,n,replace=T,prob=fx) #2 Sustituie la n.
trial = sample(x,4000,replace=T,prob=fx)

mean(trial) #3 Promedio.
var(trial) #4 Varianza.

##pregunta 4##

#1#

#Poner la media i la desviacion tipica que te dice y te saldra un codigo parecido al de abajo,
.x <- seq(1.188, 12.212, length.out=1000) 
plot(.x, dnorm(.x, mean=8.1, sd=1.965), cdf=FALSE, xlab="x", ylab="Density",main=paste("Normal Distribution:  Mean=6.7, Standard deviation=1.675"))

#2#
#Variar el c(3.35)= pese mas de x, mean = media, sd = desviacion tipica.
pnorm(c(1.6), mean=8.1, sd=1.965, lower.tail=FALSE)

#3#
#Procedimiento como antes y el P1 es para el que dice PESE MAS DE X y el P2 es para el que 
#3 dice MENOS QUE X KILOGRAMOS.
P1 = pnorm(c(7.2), mean=8.1, sd=1.965, lower.tail=TRUE)
P2 = pnorm(c(8.1), mean=8.1, sd=1.965, lower.tail=TRUE)
P2-P1 #SOL 

#4
#Variar el c(0.57) por el percentil que te digan y modificar media i desviacion tipica.
qnorm(c(0.54), mean=8.1, sd=1.965, lower.tail=TRUE)          

#5#
#mean= media*Grupo de caniches, sd= desviacion tipica*Numero de caniches c(60.9) poner 
#5 MENOR QUE X KILOGRAMOS.
7*8.1
7*1.965
pnorm(c(48.3), mean=56.7, sd=13.755, lower.tail=TRUE)

