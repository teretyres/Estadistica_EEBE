"Pregunta 1"
x1=c(45,46,47,48,49,50,51,52,53,54,55)
f1=c(0.17,0.15,0.11,0.07,0.05,0.03,0.05,0.07,0.04,0.09,0.17)

#1) 
media <- sum(x1*f1); media
#b
F = cumsum(f1);
F
#c)
varianza <- sum((x1-media)^2*f1); varianza

#d) trials=sample(x,1000,replace=True,fx)
x1=c(45,46,47,48,49,50,51,52,53,54,55)
f1=c(0.17,0.15,0.11,0.07,0.05,0.03,0.05,0.07,0.04,0.09,0.17)
simulacion <- sample(x1,1000,f1,replace = TRUE,prob=f1)

#e)(GR?FICA)
plot(x1,f1,col="red", type = "p")
points(x,fx,col="red",pch=16)
for(i in 1:11)
{ lines(c(x1[i], x1[i]), c(0, f1[i])) }

##problema 2##

#1#
ppois(26,30) #promedio 30, 26 conejos o menos?




"Pregunta 3"
f <- function(x)
{
  out <-((sqrt(30)/75)*(sqrt(x)))
  out[x<=0] <- 0
  out[x>=15/2] <- 0
  out
}
#1)(GRAFICA)
x <- seq(0,8,0.001);x
fx<- f(x);fx
plot(x,fx,col="red",type = "l")

#2)trials=sample(x,4000,replace = TRUE,prob = fx)
simulacion<- sample(x,replace = TRUE,size = 300000,prob = fx)

#3)3.609473
mean(simulacion)

#4)2.457218
var(simulacion)




"Pregunta 4"
media <- 76
desviacion <- sqrt(357.2) #sqrt si te dan varianza
#b
x4 <- seq(0,140,0.1); x4
f4 <- dnorm(x4,media,desviacion); f4
plot(x4,f4,type = "l",col="red")

1-pnorm(104.2,media,desviacion) #probabilidad q tenga mas de 1.5

#c
pnorm(83,media,desviacion)-pnorm(43.2, media,desviacion) #tenga entre 2.5 y 5.3

#d
percentil<-qnorm(0.18,media,desviacion); percentil #percentil  0.73


#e
xi<- 48.4 #medida liquido inferior a 
pruebas<- 15 #nº pruebas
pnorm(xi,media*pruebas,desviacion*sqrt(pruebas)) #probabilidad

