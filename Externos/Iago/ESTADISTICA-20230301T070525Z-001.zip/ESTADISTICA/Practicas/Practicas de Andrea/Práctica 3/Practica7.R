exp1 <- c(3.889533, 4.800898, 4.262898, 4.361508,
          5.617505, 3.423186, 3.575229, 6.961411, 3.833203,
          3.560329)

barx <- mean(exp1)

barx

z0.025 <- qnorm(0.025)
z0.025

fsup <- 1.959964*1.4/sqrt(10)

fsup

CI <- c(barx-fsup,barx+fsup)
CI

library(TeachingDemos)

z.test(exp1,sd=1.4)

qt(0.025,df=9)


barx <- mean(exp1)
barx

s <-sd(exp1)
s

fsup <- 2.262157*s/sqrt(10)
fsup

CI <- c(barx-fsup,barx+fsup)
CI

t.test(exp1, conf.level = 0.95)

t.test(exp1, conf.level = 0.99)

s<-sd(exp1)
s

s^2

chiInf<-qchisq(0.025, df=n-1)

chiSup<-qchisq(0.975, df=n-1)

n<-10

CI<-c(s^2*(n-1)/chiSup, s^2*(n-1)/chiInf)
CI

sigma.test(exp1)

