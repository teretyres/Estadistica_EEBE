baterias <- read.table("PLN_Number_SOC_Temp_StoragePeriod.csv",
                       header=TRUE, sep=",")
baterias

complete.cases(baterias)

baterias <- baterias[complete.cases(baterias),]
head(baterias)

descarga <- baterias$Discharge.Capacity

selectEstandard <- baterias$TEMP==50 & baterias$SOC==100
selectEstandard

descargaEstandard <- descarga[selectEstandard]

mu0 <- mean(descargaEstandard)
mu0


sigma0 <- sd(descargaEstandard)
sigma0


selectTest <- baterias$TEMP==50 & baterias$SOC==0
x <- descarga[selectTest]

barx <- mean(x)
barx

n <- length(x)
n

hist(x, freq=FALSE)

xint<-seq(1.53,1.6,0.001)
plot(xint,dnorm(xint,barx,sigma0/sqrt(n)), type="l",col="blue")
lines(xint,dnorm(xint,barx,sigma0))
points(barx,0,pch=16,col="black")


plot(xint,dnorm(xint,barx,sigma0/sqrt(n)),type="l",col="blue")
points(barx,0,pch=16,col="black")

lines(xint,dnorm(xint,mu0,sigma0/sqrt(n)),col="red",lty=2)
points(mu0,0,pch=16,col="red",cex=1.5)

library(TeachingDemos)
z.test(x, sd=sigma0, mu=mu0, conf.level=0.95)

points(c(1.561907, 1.576557),c(0,0),pch=16,col="orange")


Z<-(xint-mu0)/(sigma0/sqrt(n))

plot(Z,dnorm(Z),col="red",type="l")
z<-(barx-mu0)/(sigma0/sqrt(n))
z

points(z,0,pch=16)

qnorm(c(0.025,0.975))
points(c(-1.959964,1.959964),c(0,0),pch=16,col="orange")
points(z,0,pch=16)

pnorm(z)

plot(Z,dnorm(Z),col="red",type="l")
points(z,0,pch=16,cex=1.5)

abline(v=z)
abline(v=-z)


pval<-2*(1-pnorm(z))
pval

z.test(x, sd=sigma0, mu=mu0, conf.level=0.95)


qnorm(0.95)

plot(Z,dnorm(Z),col="red",type="l")
points(z,0,pch=16)
abline(v=qnorm(0.95))

pval <- 1-pnorm(z)
pval

z.test(x, sd=sigma0, mu=mu0, conf.level=0.95,
       alternative="greater")

z.test(x, sd=sigma0, mu=mu0, conf.level=0.99,
       alternative="greater")

t.test(x, mu=mu0, conf.level=0.95)
