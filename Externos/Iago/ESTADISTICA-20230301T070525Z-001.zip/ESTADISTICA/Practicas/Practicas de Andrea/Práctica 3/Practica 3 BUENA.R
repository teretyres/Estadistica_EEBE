#EJERCICIO 1
# n = 73 xbar=9.5 y desv est = 1.94 IC= 90%
barx <- 9.5
barx

s <-1.94
s

qnorm <- qnorm(0.05)
qnorm

fsup <- qnorm*s/sqrt(73)
fsup

CI <- c(barx-fsup,barx+fsup)
CI


#EJERCICIO 2


#EJERCICIO 3
muestras <- c(3.53,3.67,3.53,3.62,3.68,3.72,3.74,3.58,3.66,3.58,3.66,3.79,3.49,3.75,
             3.86,3.62,3.7,3.56,3.75,3.58,3.75,3.42,3.55,3.41,3.7,3.7,3.66,3.62,
             3.44,3.64,3.74,3.77,3.64,3.68,3.54,3.51,3.75,3.64,3.78,3.5,3.65,
             3.61,3.58,3.7,3.74,3.78,3.64,3.56,3.88,3.67,3.74,3.39,3.44,3.61)
s <- sd(muestras)
sc <- s*sqrt(54/53)
xbar <- mean(muestras)
qnorm <- qt(0.01,df=53)
fsub <- qnorm*s/sqrt(54)
ci <- c(xbar-fsub,xbar+fsub)
ci

#EJERCICIO 4


#EJERCICIO 5


