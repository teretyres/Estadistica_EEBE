#Una compañía americana está interesada en el mercado de coches de antiguos. Su objetivo a corto plazo es especializarse en alguno de estos modelos. Entre otros atributos, le interesan aquellos que cumplan los requisitos de mayor eficiencia y menor consumo.

#Para ello selecciona una muestra de 155 vehículos de esa época, para hacer un estudio de sus características. El fichero vehiculos80.xls, contiene datos relativos a 155 coches de distintas procedencia (Estados Unidos, Europa y Japón) (periodo 1978−82). Estos coches se comercializaban en USA, en los años 80.

#Las variables que contiene son:
  
#mpg (millas por galón de combustible), cylinders (cilindros), horsepower (caballos de potencia), price (precio), weight=kilos), accel=segundos que tarda en alcanzar la velocidad 60 millas por hora, origin (origen), year (año), model (modelo), make (fábrica) y displace (capacidad de los cilindros en pulgadas cúbicas)
  
#Primero de todo cargaremos la tabla
  

VEHICULOS <- read_excel("~/UPC/2o a�o/4o quadrimestre/ES/Actividades/data_trabajo/VEHICULOS.xlsx")
attach(VEHICULOS)
  
#1. El fichero vehiculos80.xls, contiene datos relativos a 155 coches de los años 80, de distintas procedencia (Estados Unidos, Europa y Japón).
#Una compañía americana está interesada en el mercado de estos coches antiguos y desea hacer un estudio de fiabilidad, en términos de aceleración ( tiempo t, en segundos de 0 a 100 kms) y consumo (número litros en 100 Kms), con un nivel de confianza del 99%.**

  #a. Estudio de normalidad de la población.**
    #a.1) ¿Podemos asumir normalidad en la variable consumo ?. ¿ y aceleración?**
  
    #Ya que el nombre de datos de la variable conaumo y aceleración es mayor que 30, utilizando el Teorema Central del Límite podemos obviar el hecho de que las variables no siguen una distribución normal.

    #a.2) Se decide estudiar el consumo de los coches según su origen, comenzando con los americanos. Se puede asumir normalidad en dichas variables?.**
  

tapply(mpg, origin, length)

    #Como podemos observar i basándonos en lo que hemos explicado en el apartado anterior, podemos decir que los coches americanos (1) i los japoneses (3) si siguen una distribución normal ya que el número de muestras es mayor que 30, en cambio, con los coches europeos no podemos suponer que siguen una distribución normal porque el número de muestras es inferior a 30.

  #b. Estimaciones puntuales de la media y varianza del consumo de los coches americanos.**
  
  #Primer farem l'estimació de la mit


  #c. �Podemos calcular un intervalo de confianza al 99% para el consumo de los coches americanos?. En caso afirmativo indica cuál es.**

  #Si. El intervalo de confianza a calcular se hará a partir de la t de Student ya que el parámetro sigma es desconocido.


alfa<- 1-0.99
n<-85
mean(mpg[which(origin==1)], na.rm=TRUE)+c(-1,1)*qt(1-alfa/2, df=n-1)*sd(mpg[which(origin==1)], na.rm = TRUE)/sqrt(n)


  #d. ¿Podemos calcular un intervalo de confianza al 95% para la variabilidad del consumo de los coches americanos?. En caso afirmativo indica cuál es.**

  #Para calculare el extremo superior del intervalo:


alfa1<- 1-0.95
n<-85
(n-1)*var(mpg[which(origin==1)], na.rm = T)/qchisq(alfa1/2, df=n-1)


  #Para calcular el extremo inferior del intervalo:


(n-1)*var(mpg[which(origin==1)], na.rm = T)/qchisq(1-alfa1/2, df=n-1)


  #Por lo tanto el intervalo de confianza será [28.27972 , 51.96414]

