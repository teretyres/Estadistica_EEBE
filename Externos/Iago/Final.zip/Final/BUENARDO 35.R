#Estimación por intervalos de confianza
#Intervalos con z.test: conocemos sigma y tenemos datos
sigma = sigma
consumo = c(datos)
n = length(consumo)
x_bar = mean(consumo)
alfa = #1-confianza(%)
z_alfamedios = qnorm(1-alfa/2); z_alfamedios
Errorestandar = sigma/sqrt(n); Errorestandar
MargenError = z_alfamedios*Errorestandar; MargenError
Intervaloconfianza = x_bar+c(-MargenError,MargenError); Intervaloconfianza
install.packages("TeachingDemos") #instalar TeachingDemos
library(TeachingDemos)
z.test(consumo,stdev=1,conf.level=0.99)

#Intervalos con t.test: no conocemos sigma(sd) pero tenemos datos
consumo = c(datos)
n = length(consumo)
S = sd(consumo)
x_bar = mean(consumo)
alfa = #1-confianza(%)
t_alfamedios = qt(1-alfa/2,n-1)
Errorestandar= S/sqrt(n); Errorestandar
MargenError = t_alfamedios*Errorestandar; MargenError
Intervaloconfianza = x_bar+c(-MargenError,MargenError); Intervaloconfianza
t.test(consumo, conf.level = 0.99)

#Intervalos con un sigma.test: 
peso =c(datos)
n = length(peso)
alfa = #1-confianza(%)
S = sd(peso)
var = S^2;var
chi_a = qchisq(alfa/2,n-1);chi_a
chi_b = qchisq(1-alfa/2,n-1);chi_b
Intervaloconfianza_var = c((n-1)*S^2/chi_b,(n-1)*S^2/chi_a); Intervaloconfianza_var
Intervaloconfianza_desv = sqrt(Intervaloconfianza_var); Intervaloconfianza_desv
install.packages("TeachingDemos") #instalar TeachingDemos
library(TeachingDemos)
sigma.test(peso)


#Intervalos con un prop.test:
n= masa
p= casos_a_favor/n
mu = p
alfa = 1-conf
conf = 1-alfa
sigma = sqrt(p*(1-p)/n)
z_alfamedios = qnorm((1+conf)/2); z_alfamedios
Error = z_alfamedios*sigma; Error
IC = c(p-Error,p+Error); IC


#Contraste de hipotesis
#caso 1: Conocemos sigma y tenemos datos(z.test)
install.packages("TeachingDemos")
library(TeachingDemos)
x = c(datos)
n = length(x)
varianza = sigma^2
sigma = sqrt(varianza)
alfa = #1-confianza(%)
  limite = mu
z_obs = (mean(x)-limite)/(sigma/sqrt(n)); z_obs
z_critico = qnorm(alfa); z_critico
p_valor=2-2*pnorm(z_obs);p_valor #Bilateral
p_valor=1-pnorm(z_obs);p_valor #z_obs > z_critico
p_valor=pnorm(z_obs);p_valor #z_obs < z_critico
#Rechazamos hipotesis si p_valor < alfa
#z.test insatantaneo, encontrar z_obs(z) y p_valor(p-value)
#Ho: mu < limite o mu <= limite
#H1: mu >= limite o mu > limite
z.test(x,mu=limite,stdev=sqrt(varianza),alternative = "greater",conf.level = (1-alfa))
#Ho: mu >= limite o mu > limite
#H1: mu < limite o mu <= limite
z.test(x,mu=limite,stdev=sqrt(varianza),alternative = "less",conf.level = (1-alfa))
#Ho: mu = limite o mu = limite
z.test(x,mu=limite,stdev=sqrt(varianza),alternative = "two.sided",conf.level = (1-alfa))


#caso 2: No conocemos sigma y tenemos datos(t.test)
install.packages("TeachingDemos")
library(TeachingDemos)
x = c(datos)
n = length(x)
S = sd(x)
limite = mu
alfa = #1-confianza(%)
t_critico = qt(1-(alfa/2),n-1); t_critico #Bilateral
t_critico = qt(1-(alfa),n-1); t_critico #No bilateral
t_obs = (mean(x)-limite)/(sd(x)/sqrt(n)); t_obs
p_valor = 2-2*pt(t_obs,n-1); p_valor #Bilateral
p_valor = 1-pt(t_obs,n-1); p_valor #t_obs > t_critico
p_valor = pt(t_obs,n-1); p_valor #t_obs < t_critico
#Rechazamos hipotesis si p_valor < alfa
#z.test insatantaneo, encontrar t_obs(t) y p_valor(p-value)
#Ho: mu < limite o mu <= limite
#H1: mu >= limite o mu > limite
t.test(x,mu=limite,stdev=sd(x),alternative = "greater",sd = sd(x),conf.level = (1-alfa))
#Ho: mu >= limite o mu > limite
#H1: mu < limite o mu <= limite
t.test(x,mu=limite,stdev=sd(x),alternative = "less",sd = sd(x),conf.level = (1-alfa))
#Ho: mu = limite o mu = limite
t.test(x,mu=limite,stdev=sd(x),alternative = "two.sided",sd = sd(x),conf.level = (1-alfa))


#caso 3: Nos dan sigma y no nos dan datos(sigma.test)
install.packages("TeachingDemos")
library(TeachingDemos)
sigma = sigma
n = masa
S = sd(x) #o otra sigma nueva
alfa = #1-confianza(%)
variabilidad=sigma^2
chisqpequeño= qchisq((alfa/2),n-1);chisqpequeño #Bilateral
chisqpequeño= qchisq((alfa),n-1);chisqpequeño #X_obs>X_c
chisqgrande= qchisq((1-alfa/2),n-1);chisqgrande #Bilateral
chisqgrande= qchisq((1-alfa),n-1);chisqgrande #X_obs<X_c
chisq_obs=((n-1)*S^2)/sigma^2;chisq_obs 
p_valor = 2-2*pchisq(chisq_obs, n-1); p_valor #Bilateral
p_valor = 1-pchisq(chisq_obs, n-1); p_valor #X_obs>X_c
p_valor = pchisq(chisq_obs, n-1); p_valor #X_obs<X_c
#Ho: mu < limite o mu <= limite
#H1: mu >= limite o mu > limite
sigma.test(x,sigma=sigma,sigmasq = sigma^2, alternative="greater",conf.level = (1-alfa))
#Ho: mu >= limite o mu > limite
#H1: mu < limite o mu <= limite
sigma.test(x,sigma=sigma,sigmasq = sigma^2, alternative="less",conf.level = (1-alfa))
#Ho: mu = limite o mu = limite
sigma.test(x,sigma=sigma,sigmasq = sigma^2, alternative="two.sided",conf.level = (1-alfa))

#caso 4: Nos dan probabilidades (prop.test)
install.packages("TeachingDemos")
library(TeachingDemos)
#media= casos a favor/n
n = masa
p_o= p_o
alfa = #1-confianza(%)
z_obs= (media-p_o)/(sqrt(p_o*(1-p_o)/n)); z_obs
z_critico = qnorm(alfa); z_critico
p_valor=2-2*pnorm(z_obs);p_valor #Bilateral
p_valor=1-pnorm(z_obs);p_valor #z_obs > z_critico
p_valor=pnorm(z_obs);p_valor #z_obs < z_critico
#Ho: mu < limite o mu <= limite
#H1: mu >= limite o mu > limite
prop.test(x,n,p_o,alternative = "greater",conf.level = 1-alfa)
#Ho: mu >= limite o mu > limite
#H1: mu < limite o mu <= limite
prop.test(x,n,p_o,alternative = "less",conf.level = 1-alfa)
#Ho: mu = limite o mu = limite
prop.test(x,n,p_o,alternative = "two.sided",conf.level = 1-alfa)