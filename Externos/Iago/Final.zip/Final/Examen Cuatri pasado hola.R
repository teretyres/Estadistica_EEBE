#caso 1: Conocemos sigma y tenemos datos(z.test)
install.packages("TeachingDemos")
library(TeachingDemos)
x = c(23.3,22.5,21.9,21.5,19.9,21.3,21.7,23.8,22.6,24.7)
n = length(x)
varianza = 1.96
sigma = sqrt(varianza)
alfa = 0.05
limite = 23
z_obs = (mean(x)-limite)/(sigma/sqrt(n)); z_obs
z_critico = qnorm(alfa); z_critico
p_valor=pnorm(z_obs);p_valor
#Rechazamos hipotesis si p_valor < alfa
#z.test insatantaneo, encontrar z_obs(z) y p_valor(p-value)
#Ho: mu < limite o mu <= limite
#H1: mu >= limite o mu > limite
z.test(x,mu=limite,stdev=sqrt(varianza),alternative = "less",sd = sqrt(varianza),n,conf.level = (1-alfa))
#Ho: mu >= limite o mu > limite
#H1: mu < limite o mu <= limite
z.test(x,mu=limite,stdev=sqrt(varianza),alternative = "greater",sd = sqrt(varianza),n,conf.level = (1-alfa))
#Ho: mu = limite o mu = limite
z.test(x,mu=limite,stdev=sqrt(varianza),alternative = "two.sided",sd = sqrt(varianza),n,conf.level = (1-alfa))