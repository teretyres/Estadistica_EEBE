dat = mtcars;
plot(dat$disp, dat$wt);

modelo = lm(wt~disp, data=dat);
summary(modelo);

print(paste("Pendiente m:", coef(modelo)[2]));
print(paste("Interseccion b:", coef(modelo)[1]));
print("R-cuadrado ajustado se encuentra en summary");
print("Múltiple R-cuadrado también se encuentra en summary");