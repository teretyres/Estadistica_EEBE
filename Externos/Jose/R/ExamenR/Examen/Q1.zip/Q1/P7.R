print(paste("Determinacion = R^2 =", 0.1758));
print(paste("Correlacion = R =",sqrt(0.1758)));

# MARKETVALUE~ASSETS
bm_a = 9.33225;
mm_a = 0.04323;

# ASSETS~MARQUETVALUE
ba_m = 29.134;
ma_m = 4.066;

print("Variación del valor de mercado al AUMENTAR 1 PUNTO los assets:");
print("    - Esto es igual a la pendiente de ASSETS=V.Ind, MARKETVALUE=V.Dep");
print("    - Otra manera de escribir la relacion es MARKETVALUE~ASSETS");
print(paste("    - Pendiente =", mm_a));

# MERCADO~ASSETS
activos = 132.8;
mercado = bm_a + mm_a * x_val;

print(paste0("MARQUETVALUE(",activos,")= ", mercado))