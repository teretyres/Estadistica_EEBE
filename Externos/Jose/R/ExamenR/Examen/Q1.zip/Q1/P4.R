n = 24;

#-------------------
X = seq(from=0, to=pi, by=pi/n);
SX = sum(X);

#-------------------
posiciones_eliminadas= c(21,24,5);
Y = X[-posiciones_eliminadas];
SXSY = sum(sin(X)) - sum(cos(Y));

#-------------------

print(paste("Suma de X:", SX));
print(paste("S(sin(x)) - S(cos(y)):", SXSY));
print(Y[17]<=Y[5])