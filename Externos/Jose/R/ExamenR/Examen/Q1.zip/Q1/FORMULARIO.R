v = c(1,3,5,2,5,3,2,1,5,NA) ;
v = c(v, seq(0,pi, pi/16));


##############################################################
## OPERACIONES BASICAS
##############################################################

# VECTOR REPETITIVO:
c(rep(3,40)); #"3" 40 veces

# SUMATORIO
sum(c(1,2,3,4)); # Devuelve la suma

# INTERVALOS DE VECTOR
v[1:50]; # 50 primeros valores

# VECTOR SECUENCIA
seq(from=0, to=10, by=0.5);

# APLICAR CALCULO A VECTOR
V = sin(v);

# ELIMINAR VALORES DE VECTOR
# v[-c(1,2,3)]; # ELimina según la posición

# MAX MIN
max(v, na.rm = T);
min(V, na.rm = T);

# INDICE DE VALOR
match(5, v);

# CREAR TABLA DATOS
datos = data.frame(v,V);


##############################################################
## FRECUENCIAS
##############################################################

# FRECUENCIA ABSOLUTA (ni)
table(datos$V);

# FRECUENCIA RELATIVA (fi)
table(datos$V)/length(datos$V); # SI tiene en cuenta los NA
table(datos$V)/length(datos$V[which(!is.na(datos$V))]); # NO tiene en cuenta los NA

# FRECUENCIA ABSOLUTA ACUMULATIVA (Ni)
cumsum(table(datos$V))

# FRECUENCIA RELATIVA ACUMULATIVA (Fi)
cumsum(  table(datos$V)/length(datos$V)  ); # SI tiene en cuenta los NA
cumsum( table(datos$V)/length(datos$V[which(!is.na(datos$V))]) ); # NO tiene en cuenta los NA


##############################################################
## GRAFICOS
##############################################################

# GRAFICO GENERAL
plot(datos);

# GRAFICO DE PUNTOS
dotchart(datos$v);

# GRAFICO DE BARRAS
barplot(table(datos$v));

# GRAFICO DE TALLO
# stem(datos$v);

# GRAFICO DE SECTORES
pie(table(datos$v));

# GRAFICO DE CAJAS
boxplot(datos);


##############################################################
## MEDIA Y VARIACION
##############################################################

# MEDIA
mean(v, na.rm = T);
mean(v[which(!is.na(v))]);

# MEDIANA
median(v, na.rm = T);

# QUARTIL
quantile(v, 0.25, na.rm = T);
quantile(v, 0.18, na.rm = T);

# RANGO INTERQUARTILICO
IQR(v, na.rm = T);

# DESVIACION TIPICA (CORREGIDA)
sd(v, na.rm = T);
sd(v[which(!is.na(v))]);

# VARIANZA (CORREGIDA)
var(v , na.rm = T);
var(v [which(!is.na( v ))]);
sd(v , na.rm = T)^2;


##############################################################
## MEDIA Y VARIACION
##############################################################

# MODELO LINEAR
modelo = lm(V~v, data=datos) #Dependiente~Independiente
m = coef(modelo[2]);
b = coef(modelo[1]);
summary(modelo);
x_val = 10;
y_val = coef(modelo)[1] + coef(modelo)[2]*x_val;

# MODELO EXPONENCIAL
q = V[which(
  !is.na(log(!is.na(V))) & 
  !is.infinite(log(!is.na(V)))
            )];

p = v[which(
  !is.na(log(!is.na(V))) & 
  !is.infinite(log(!is.na(V)))
            )];
modelo = lm(q~p) #Dependiente~Independiente
summary(modelo);
x_val = 10;
y_val = exp(coef(modelo)[1] + coef(modelo)[2]*x_val);

# CORRELACION (R)
cor(p,q); #Ind,Dep

# CORRELACION^2 (R^2)
cor(p,q)^2; #Ind,Dep





