rm(list=ls())
data <- trees

stem(data$Volume)
