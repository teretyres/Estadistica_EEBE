# Se debe importar el dataset notas.txt
notas = read.table("notas.txt", header=TRUE, sep="\t", dec=".")

datos = notas$S7;

print("ni:");
print(table(datos));

print("Ni:");
print(cumsum(table(datos)));

print("fi:");
print(table(datos)/length(datos));

print("Fi:")
print(cumsum(table(datos)/length(datos)));