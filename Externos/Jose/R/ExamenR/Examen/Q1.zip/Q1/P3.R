dat = mtcars;

print(paste("Media de qsec:", mean(dat$qsec)));
print(paste("Mediana de drat:", median(dat$drat)));
print(paste("1r Quartil de drat:", quantile(dat$drat, 0.25)));
print(paste("18% Quantil de wt:", quantile(dat$wt, 0.18)));
print(paste("IQR de mpg:", IQR(dat$mpg)));
print(paste("Desviacion tipica corregida de hp:", sd(dat$hp)));
print(paste("Varianza corregida de mpg:", var(dat$mpg)));

